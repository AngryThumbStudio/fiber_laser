# License

Ramp Card Jig STEP and STL Files  
Copyright (c) 2026 Joshua O'Hara / Angry Thumb Studio

This work is licensed under the Creative Commons Attribution 4.0 International License.

You are free to share, copy, redistribute, remix, transform, and build upon this work for any purpose, including commercial purposes, provided that appropriate credit is given.

Attribution should include:

- Creator: Joshua O'Hara / Angry Thumb Studio
- Work: Ramp Card Jig STEP and STL Files
- License: Creative Commons Attribution 4.0 International (CC BY 4.0)
- License URL: https://creativecommons.org/licenses/by/4.0/

Suggested attribution:

"Ramp Card Jig STEP and STL Files" by Joshua O'Hara / Angry Thumb Studio is licensed under CC BY 4.0.

If you modify these files, please indicate that changes were made.

No endorsement is implied. Use of this work does not suggest that Joshua O'Hara or Angry Thumb Studio endorses any modified version, product, or use.